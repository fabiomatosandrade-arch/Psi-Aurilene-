
import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { User, DailyEntry, Mood } from '../types';
import { generateReportPDF } from '../utils/pdfGenerator';

interface ReportsProps {
  user: User;
}

type FilterPeriod = 'all' | 'week' | 'month' | 'year';

const ITEMS_PER_PAGE = 10;

const Reports: React.FC<ReportsProps> = ({ user }) => {
  const [allUserEntries, setAllUserEntries] = useState<DailyEntry[]>([]);
  const [filteredEntries, setFilteredEntries] = useState<DailyEntry[]>([]);
  const [filter, setFilter] = useState<FilterPeriod>('all');
  const [visibleCount, setVisibleCount] = useState(ITEMS_PER_PAGE);
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedEntry, setSelectedEntry] = useState<DailyEntry | null>(null);
  const [moodStats, setMoodStats] = useState<{ mood: Mood; count: number; label: string; emoji: string; color: string }[]>([]);
  const [dataAgeWarning, setDataAgeWarning] = useState<string | null>(null);

  useEffect(() => {
    const allEntries: DailyEntry[] = JSON.parse(localStorage.getItem('psicolog_entries') || '[]');
    const userEntries = allEntries.filter(e => e.userId === user.id)
      .sort((a, b) => b.timestamp - a.timestamp);
    setAllUserEntries(userEntries);
  }, [user.id]);

  useEffect(() => {
    const now = Date.now();
    const periods = {
      week: { ms: 7 * 24 * 60 * 60 * 1000, label: 'Semana' },
      month: { ms: 30 * 24 * 60 * 60 * 1000, label: 'Mês' },
      year: { ms: 365 * 24 * 60 * 60 * 1000, label: 'Ano' },
    };

    let filtered = [...allUserEntries];
    setDataAgeWarning(null);

    if (filter !== 'all') {
      const p = periods[filter];
      const threshold = now - p.ms;
      filtered = allUserEntries.filter(e => e.timestamp >= threshold);

      // Validação: Verificar se o histórico total é menor que o período selecionado
      if (allUserEntries.length > 0) {
        const oldestEntry = allUserEntries[allUserEntries.length - 1];
        const historyDuration = now - oldestEntry.timestamp;
        
        if (historyDuration < p.ms) {
          const daysTotal = Math.ceil(historyDuration / (24 * 60 * 60 * 1000));
          setDataAgeWarning(`O período de um(a) ${p.label} excede seu histórico. Você possui registros de apenas ${daysTotal} dia(s).`);
        }
      }
    }
    
    setFilteredEntries(filtered);
    setVisibleCount(ITEMS_PER_PAGE);

    const stats = [
      { mood: Mood.EXCELLENT, count: 0, label: 'Muito Bem', emoji: '😄', color: 'bg-emerald-500' },
      { mood: Mood.GOOD, count: 0, label: 'Bem', emoji: '🙂', color: 'bg-blue-400' },
      { mood: Mood.NEUTRAL, count: 0, label: 'Neutro', emoji: '😐', color: 'bg-slate-300' },
      { mood: Mood.BAD, count: 0, label: 'Mal', emoji: '🙁', color: 'bg-orange-400' },
      { mood: Mood.VERY_BAD, count: 0, label: 'Muito Mal', emoji: '😞', color: 'bg-red-500' },
    ];

    filtered.forEach(entry => {
      const stat = stats.find(s => s.mood === entry.mood);
      if (stat) stat.count++;
    });

    setMoodStats(stats);
  }, [allUserEntries, filter]);

  const handleDownloadPDF = () => {
    if (filteredEntries.length === 0) {
      alert('Não há registros para gerar relatório neste período.');
      return;
    }
    setIsGenerating(true);
    
    setTimeout(() => {
      try {
        const doc = generateReportPDF(user, filteredEntries);
        const fileName = `Relatorio_Psi_Aurilene_${user.username}_${filter}_${new Date().toISOString().split('T')[0]}.pdf`;
        doc.save(fileName);
      } catch (error) {
        console.error("Erro ao gerar PDF:", error);
        alert("Ocorreu um erro ao gerar o relatório. Tente novamente.");
      } finally {
        setIsGenerating(false);
      }
    }, 1000);
  };

  const shareEntryWhatsApp = (entry: DailyEntry) => {
    const dateStr = new Date(entry.date).toLocaleDateString('pt-BR');
    const text = `Registro Diário (${dateStr}) - Psi.Aurilene\n\nHumor: ${getMoodLabel(entry.mood)}\nRelato: ${entry.notes}`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
    setSelectedEntry(null);
  };

  const shareEntryEmail = (entry: DailyEntry) => {
    const dateStr = new Date(entry.date).toLocaleDateString('pt-BR');
    const subject = `Registro Terapêutico - ${dateStr}`;
    const body = `Olá,\n\nSegue registro do dia ${dateStr}:\n\nHumor: ${getMoodLabel(entry.mood)}\n\nRelato:\n${entry.notes}\n\nEnviado via App Psi.Aurilene`;
    const url = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.open(url, '_blank');
    setSelectedEntry(null);
  };

  const getMoodLabel = (mood: Mood) => {
    const m = moodStats.find(s => s.mood === mood);
    return m ? `${m.emoji} ${m.label}` : '';
  };

  const maxCount = Math.max(...moodStats.map(s => s.count), 1);

  const filters: { value: FilterPeriod; label: string }[] = [
    { value: 'all', label: 'Tudo' },
    { value: 'week', label: 'Semana' },
    { value: 'month', label: 'Mês' },
    { value: 'year', label: 'Ano' },
  ];

  const resetFilters = () => {
    setFilter('all');
  };

  const loadMore = () => {
    setVisibleCount(prev => prev + ITEMS_PER_PAGE);
  };

  const paginatedEntries = filteredEntries.slice(0, visibleCount);
  const hasMore = filteredEntries.length > visibleCount;

  return (
    <Layout title="Relatórios" onBack={() => window.location.hash = '#dashboard'}>
      <div className="space-y-6 pb-20">
        {/* Period Selector & Clear Action */}
        <div className="space-y-3">
          <div className="flex bg-slate-100 p-1 rounded-2xl">
            {filters.map((f) => (
              <button
                key={f.value}
                onClick={() => setFilter(f.value)}
                className={`flex-1 py-2 px-3 text-[10px] font-bold uppercase tracking-wider rounded-xl transition-all ${
                  filter === f.value 
                    ? 'bg-white text-amber-600 shadow-sm' 
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
          
          {filter !== 'all' && (
            <button 
              onClick={resetFilters}
              className="flex items-center gap-2 mx-auto text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-amber-600 transition-colors"
            >
              <i className="fas fa-times-circle"></i>
              Limpar Filtros
            </button>
          )}
        </div>

        {/* Validation Warning */}
        {dataAgeWarning && (
          <div className="bg-amber-50 border border-amber-100 p-4 rounded-2xl flex gap-3 animate-in fade-in zoom-in duration-300">
            <i className="fas fa-info-circle text-amber-500 mt-1"></i>
            <div>
              <p className="text-[10px] font-black text-amber-800 uppercase tracking-tight">Aviso de Período</p>
              <p className="text-[10px] text-amber-700 leading-tight mt-1">{dataAgeWarning}</p>
            </div>
          </div>
        )}

        {/* Primary Action: PDF Button */}
        <div className="px-1">
          <button
            onClick={handleDownloadPDF}
            disabled={isGenerating || filteredEntries.length === 0}
            className="w-full gold-gradient text-white flex items-center justify-center gap-3 p-4 rounded-2xl shadow-lg hover:shadow-amber-200/50 transition-all disabled:opacity-50 active:scale-[0.98] font-bold text-xs tracking-widest"
          >
            {isGenerating ? (
              <i className="fas fa-spinner fa-spin text-lg"></i>
            ) : (
              <i className="fas fa-file-pdf text-lg"></i>
            )}
            {isGenerating ? 'GERANDO RELATÓRIO...' : 'BAIXAR RELATÓRIO PDF'}
          </button>
          {filteredEntries.length > 0 && (
             <p className="text-center text-[9px] text-slate-400 mt-2 uppercase font-bold tracking-tighter">
               Exibindo {filteredEntries.length} registros no período
             </p>
          )}
        </div>

        {/* Visual Summary (Chart) */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
              <i className="fas fa-chart-bar text-amber-500"></i>
              Frequência de Humor
            </h3>
          </div>
          <div className="space-y-4">
            {moodStats.map((stat) => (
              <div key={stat.mood} className="space-y-1">
                <div className="flex justify-between items-center text-[10px] font-bold uppercase text-slate-500">
                  <span className="flex items-center gap-2">
                    <span className="text-sm">{stat.emoji}</span>
                    {stat.label}
                  </span>
                  <span>{stat.count}</span>
                </div>
                <div className="h-2.5 w-full bg-slate-50 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${stat.color} transition-all duration-1000 ease-out`}
                    style={{ width: `${filteredEntries.length > 0 ? (stat.count / maxCount) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Detailed History */}
        <div>
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4 px-1">Registros no Período</h3>
          <div className="space-y-3">
            {filteredEntries.length === 0 ? (
              <div className="text-center py-10 bg-white rounded-2xl border border-dashed border-slate-200">
                <p className="text-slate-400 text-xs italic">Nenhum registro encontrado.</p>
              </div>
            ) : (
              <>
                {paginatedEntries.map((entry) => {
                  const moodInfo = moodStats.find(s => s.mood === entry.mood);
                  return (
                    <div key={entry.id} className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm group animate-in fade-in slide-in-from-bottom-2 duration-300">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex flex-col">
                          <span className="text-[10px] font-black text-amber-600 uppercase">
                            {new Date(entry.date).toLocaleDateString('pt-BR', { weekday: 'long' })}
                          </span>
                          <span className="text-sm font-bold text-slate-700">
                            {new Date(entry.date).toLocaleDateString('pt-BR')}
                          </span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="relative group/tooltip">
                            <span 
                              className="text-xl cursor-help transition-transform hover:scale-125 inline-block" 
                              aria-label={`Humor: ${moodInfo?.label}`}
                            >
                              {moodInfo?.emoji}
                            </span>
                            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-slate-800 text-white text-[10px] font-bold rounded opacity-0 group-hover/tooltip:opacity-100 transition-opacity pointer-events-none whitespace-nowrap shadow-xl z-30">
                              {moodInfo?.label}
                              <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-800"></div>
                            </div>
                          </div>
                          <button 
                            onClick={() => setSelectedEntry(entry)}
                            className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 hover:text-amber-600 hover:bg-amber-50 transition-colors"
                          >
                            <i className="fas fa-share-alt text-sm"></i>
                          </button>
                        </div>
                      </div>
                      <p className="text-slate-600 text-xs leading-relaxed line-clamp-3 italic">
                        "{entry.notes}"
                      </p>
                    </div>
                  );
                })}

                {hasMore && (
                  <button
                    onClick={loadMore}
                    className="w-full py-4 text-xs font-bold text-slate-400 uppercase tracking-widest hover:text-amber-600 transition-colors flex items-center justify-center gap-2 bg-slate-50 border border-slate-100 rounded-xl"
                  >
                    Carregar mais
                  </button>
                )}
              </>
            )}
          </div>
        </div>

        {/* Modal de Compartilhamento */}
        {selectedEntry && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <div className="bg-white w-full max-w-sm rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl animate-in slide-in-from-bottom-10 duration-300">
              <div className="flex justify-between items-center mb-6">
                <h4 className="font-bold text-slate-800 uppercase tracking-tight text-sm">Compartilhar Detalhe</h4>
                <button onClick={() => setSelectedEntry(null)} className="text-slate-400 hover:text-slate-600 p-2">
                  <i className="fas fa-times"></i>
                </button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <button 
                  onClick={() => shareEntryWhatsApp(selectedEntry)}
                  className="flex flex-col items-center gap-2 p-4 bg-green-50 rounded-2xl border border-green-100 text-green-600"
                >
                  <i className="fab fa-whatsapp text-2xl"></i>
                  <span className="text-[10px] font-bold uppercase">WhatsApp</span>
                </button>
                <button 
                  onClick={() => shareEntryEmail(selectedEntry)}
                  className="flex flex-col items-center gap-2 p-4 bg-blue-50 rounded-2xl border border-blue-100 text-blue-600"
                >
                  <i className="fas fa-envelope text-2xl"></i>
                  <span className="text-[10px] font-bold uppercase">E-mail</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Reports;
